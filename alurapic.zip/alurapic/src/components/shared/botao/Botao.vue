<template>
    <button @click="disparaAcao()" class="botao" :class="estiloDoBotao" :type="tipo"> {{ rotulo }} </button>    
</template>

['tipo', 'rotulo', 'confirmacao','estilo']
<script>
    export default {
        props: {
            tipo : {required: true, type: String},
            rotulo: {required: true, type: String},
            confirmacao: {Boolean},
            estilo: String
        },

        methods: {
            disparaAcao() {

                if (this.confirmacao) {
                    if (confirm('Confirma operação')) {
                        this.$emit('botaoAtivado');
                    }
                    return;
                }
                this.$emit('botaoAtivado');
            }
        },

        computed: {
            estiloDoBotao(){
                if (this.estilo == 'padrao' || !this.estilo) return 'botao botao-padrao';
                if (this.estilo == 'perigo') return 'botao botao-perigo';
            }
        }
    }

</script>

<style scoped lang="sass">

    @import './Botao.scss';
    
</style>