export default class Foto {
    
    constructor(titulo = '', url = '', descricao = '') {
        this.titulo     = titulo;
        this.url        = url;
        this.descricao  = descricao;
    }

}